import urlparse
import json
import re

from HTMLParser import HTMLParser


def colorize(c, s):
    print "\x1b[%dm%s\x1b[0m" % (c, s)

class Logger:
    def print_info(self, req, req_body, res, res_body, logEncrypter1):
        def parse_qsl(s):
            return '\n'.join("%-20s %s" % (k, v) for k, v in urlparse.parse_qsl(s, keep_blank_values=True))

class DebugLogger:
    def print_info(self, req, req_body, res, res_body, logEncrypter1):
        communication_log = ""
        def parse_qsl(s):
            return '\n'.join("%-20s %s" % (k, v) for k, v in urlparse.parse_qsl(s, keep_blank_values=True))

        req_header_text = "%s %s %s\n%s" % (req.command, req.path, req.request_version, req.headers)
        res_header_text = "%s %d %s\n%s" % (res.response_version, res.status, res.reason, res.headers)

        colorize(33, req_header_text)
        communication_log += req_header_text

        u = urlparse.urlsplit(req.path)
        if u.query:
            query_text = parse_qsl(u.query)
            colorize(32, "==== QUERY PARAMETERS ====\n%s\n" % query_text)
            communication_log += "==== QUERY PARAMETERS ====\n%s\n" % query_text

        cookie = req.headers.get('Cookie', '')
        if cookie:
            cookie = parse_qsl(re.sub(r';\s*', '&', cookie))
            colorize(32, "==== COOKIE ====\n%s\n" % cookie)
            communication_log += "==== COOKIE ====\n%s\n" % cookie

        auth = req.headers.get('Authorization', '')
        if auth.lower().startswith('basic'):
            token = auth.split()[1].decode('base64')
            colorize(31, "==== BASIC AUTH ====\n%s\n" % token)
            communication_log += "==== BASIC AUTH ====\n%s\n" % token

        if req_body is not None:
            req_body_text = None
            content_type = req.headers.get('Content-Type', '')

            if content_type.startswith('application/x-www-form-urlencoded'):
                req_body_text = parse_qsl(req_body)
            elif content_type.startswith('application/json'):
                try:
                    json_obj = json.loads(req_body)
                    json_str = json.dumps(json_obj, indent=2)
                    if json_str.count('\n') < 50:
                        req_body_text = json_str
                    else:
                        lines = json_str.splitlines()
                        req_body_text = "%s\n(%d lines)" % ('\n'.join(lines[:50]), len(lines))
                except ValueError:
                    req_body_text = req_body
            elif len(req_body) < 1024:
                req_body_text = req_body

            if req_body_text:
                colorize(32, "==== REQUEST BODY ====\n%s\n" % req_body_text)
                communication_log += "==== REQUEST BODY ====\n%s\n" % req_body_text

        colorize(36, res_header_text)

        cookies = res.headers.getheaders('Set-Cookie')
        if cookies:
            cookies = '\n'.join(cookies)
            colorize(31, "==== SET-COOKIE ====\n%s\n" % cookies)
            communication_log += "==== SET-COOKIE ====\n%s\n" % cookies

        if res_body is not None:
            res_body_text = None
            content_type = res.headers.get('Content-Type', '')

            if content_type.startswith('application/json'):
                try:
                    json_obj = json.loads(res_body)
                    json_str = json.dumps(json_obj, indent=2)
                    if json_str.count('\n') < 50:
                        res_body_text = json_str
                    else:
                        lines = json_str.splitlines()
                        res_body_text = "%s\n(%d lines)" % ('\n'.join(lines[:50]), len(lines))
                except ValueError:
                    res_body_text = res_body
            elif content_type.startswith('text/html'):
                m = re.search(r'<title[^>]*>\s*([^<]+?)\s*</title>', res_body, re.I)
                if m:
                    h = HTMLParser()
                    colorize(32, "==== HTML TITLE ====\n%s\n" % h.unescape(m.group(1).decode('utf-8')))
            elif content_type.startswith('text/') and len(res_body) < 1024:
                res_body_text = res_body

            if res_body_text:
                colorize(32, "==== RESPONSE BODY ====\n%s\n" % res_body_text)
                communication_log += "==== RESPONSE BODY ====\n%s\n" % res_body_text

        logEncrypter1.encrypted_logging(communication_log)